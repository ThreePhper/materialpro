import { Component} from '@angular/core';
@Component({
	selector: 'material',
	templateUrl: './material.component.html' 
})
export class MaterialComponent {
	
}