import { Component} from '@angular/core';
@Component({
	selector: 'simpleline',
	templateUrl: './simpleline.component.html' 
})
export class SimplelineComponent {
	
}